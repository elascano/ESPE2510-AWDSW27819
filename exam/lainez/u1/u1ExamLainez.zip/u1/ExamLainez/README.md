# Bank Management System - Guía de Uso

## 📋 Resumen del Proyecto
Aplicación web dinámica para gestionar información de bancos con base de datos MySQL local (XAMPP).

**Tema:** Banks  
**Operación:** Insert  
**Estudiante:** Lainez  
**Fecha:** 17 de Noviembre, 2025

---

## 🏗️ Estructura de la Base de Datos

### Atributos de la Entidad Bank (6 campos + ID):
1. **ID** - Identificador único auto-generado
2. **Bank Name** - Nombre del banco
3. **Country** - País donde opera el banco
4. **Total Assets** - Activos totales en millones USD
5. **Interest Rate** - Tasa de interés promedio (%)
6. **Foundation Year** - Año de fundación
7. **Number of Branches** - Número total de sucursales

### Valor Calculado:
**Bank Rating Score (0-100)** - Calculado usando JavaScript basado en:
- Tamaño de activos (escala logarítmica)
- Competitividad de tasa de interés
- Cobertura de red de sucursales

---

## 🚀 Instrucciones de Instalación y Uso

### Paso 1: Instalar XAMPP
1. Descarga XAMPP desde https://www.apachefriends.org/
2. Instala XAMPP en tu computadora
3. Inicia Apache y MySQL desde el panel de control de XAMPP

### Paso 2: Crear la Base de Datos
1. Abre tu navegador y ve a http://localhost/phpmyadmin
2. Haz clic en "Nueva" para crear una base de datos
3. Nombre: `bank_system`
4. Codificación: `utf8mb4_unicode_ci`
5. En la pestaña "SQL", copia y pega todo el contenido de `database_setup.sql`
6. Haz clic en "Continuar" para ejecutar el script

### Paso 3: Colocar los Archivos
1. Copia la carpeta `ExamLainez` a `C:\xampp\htdocs\`
2. La ruta completa debería ser: `C:\xampp\htdocs\ExamLainez\`
3. Asegúrate de que los archivos estén en la carpeta correcta:
   - index.html
   - insert_bank.php
   - database_setup.sql
   - README.md

### Paso 4: Acceder a la Aplicación
1. Abre tu navegador
2. Ve a: http://localhost/ExamLainez/
3. Deberías ver el formulario del sistema de gestión de bancos

---

## 📸 Capturas de Pantalla Requeridas

Crea un Google Doc con estas capturas de pantalla:

### 1. Panel de Control XAMPP
- Screenshot mostrando Apache y MySQL en estado "Running"

### 2. Creación de Base de Datos
- Screenshot de phpMyAdmin mostrando la base de datos `bank_system` creada
- Screenshot del script SQL ejecutándose exitosamente

### 3. Tabla Creada
- Screenshot de la estructura de la tabla `banks` en phpMyAdmin
- Screenshot mostrando los campos y tipos de datos

### 4. Interfaz de la Aplicación
- Screenshot del formulario web en el navegador
- Screenshot del formulario completado con datos de ejemplo

### 5. Cálculo del Rating
- Screenshot mostrando el Bank Rating Score calculado

### 6. Inserción Exitosa
- Screenshot del mensaje de éxito después de insertar datos

### 7. Verificación en Base de Datos
- Screenshot de phpMyAdmin mostrando los registros insertados en la tabla `banks`
- Screenshot con al menos 3-5 registros de prueba

---

## 💻 Technical Implementation

### Frontend (index.html)
- **HTML5** con estructura semántica
- **CSS3** con diseño moderno y responsive
- **JavaScript** para:
  - Validación de formulario en tiempo real
  - Algoritmo de cálculo de Bank Rating
  - Envío asíncrono de datos (Fetch API)
  - Actualizaciones dinámicas de UI

### Backend (insert_bank.php)
- **PHP** procesamiento del lado del servidor
- Conexión a MySQL local (XAMPP)
- Validación y sanitización de datos
- Respuestas JSON API
- Manejo de errores completo

### Computation Algorithm (JavaScript)
```
Bank Rating Score = Asset Score + Rate Score + Branch Score

- Asset Score (0-40 points): Logarithmic scale based on total assets
- Rate Score (0-30 points): Optimal range 2-5%, penalized outside
- Branch Score (0-30 points): Logarithmic scale based on branch count

Rating Categories:
- 85-100: Excellent ⭐⭐⭐⭐⭐
- 70-84: Very Good ⭐⭐⭐⭐
- 55-69: Good ⭐⭐⭐
- 40-54: Fair ⭐⭐
- 0-39: Needs Improvement ⭐
```

---

## 🔧 Checklist de Configuración

- [ ] XAMPP instalado y funcionando
- [ ] Apache y MySQL iniciados
- [ ] Base de datos `bank_system` creada en phpMyAdmin
- [ ] Script `database_setup.sql` ejecutado correctamente
- [ ] Archivos colocados en `C:\xampp\htdocs\ExamLainez\`
- [ ] Aplicación accesible en http://localhost/ExamLainez/
- [ ] Formulario probado exitosamente
- [ ] Datos verificados en phpMyAdmin
- [ ] Capturas de pantalla tomadas para documentación
- [ ] Google Doc creado con evidencias

---

## 🧪 Testing Scenarios

### Test Case 1: Small Local Bank
- Bank Name: Community Trust Bank
- Country: Ecuador
- Total Assets: 500 (million USD)
- Interest Rate: 4.5%
- Foundation Year: 2010
- Branches: 25
- **Expected Rating:** Fair/Good

### Test Case 2: Large International Bank
- Bank Name: Global Finance Corporation
- Country: United States
- Total Assets: 500000 (million USD)
- Interest Rate: 3.2%
- Foundation Year: 1985
- Branches: 5000
- **Expected Rating:** Excellent

### Test Case 3: Medium Regional Bank
- Bank Name: Regional Savings Bank
- Country: Spain
- Total Assets: 15000 (million USD)
- Interest Rate: 2.8%
- Foundation Year: 1995
- Branches: 350
- **Expected Rating:** Very Good/Excellent

---

## 📚 Recursos Adicionales

### Documentación XAMPP:
https://www.apachefriends.org/docs/

### Documentación PHP MySQL:
https://www.php.net/manual/es/book.mysqli.php

### Tutorial phpMyAdmin:
https://docs.phpmyadmin.net/es/latest/

---

## ⚠️ Notas Importantes

1. **Seguridad**: El sistema usa las credenciales por defecto de XAMPP (root sin contraseña)
2. **Validación**: Implementada tanto en cliente (JavaScript) como en servidor (PHP)
3. **Manejo de Errores**: Mensajes de error comprensivos para debugging
4. **Código Limpio**: Todo el código está bien comentado para mantenimiento
5. **Base de Datos**: La tabla se crea automáticamente con el script SQL

---

## 📞 Solución de Problemas

Si encuentras problemas:
1. Verifica que Apache y MySQL estén corriendo en XAMPP
2. Asegúrate de que la base de datos `bank_system` exista
3. Revisa la consola del navegador para errores JavaScript
4. Verifica que los archivos estén en la carpeta correcta de htdocs
5. Comprueba que puedas acceder a phpMyAdmin (http://localhost/phpmyadmin)

---

**Estado del Proyecto:** ✅ Completo y Listo para Usar
**Requisitos Cumplidos:** Todos los requisitos cumplidos (operación INSERT, 5+ atributos, cómputo en JavaScript, base de datos MySQL)
