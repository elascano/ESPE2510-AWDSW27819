<?php
ob_start();

error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);

ob_clean();

header('Content-Type: application/json; charset=utf-8');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido');
    }

    $host = 'localhost';
    $database = 'if0_40444146_bank_system';
    $username = 'if0_40444146';
    $password = 'w7quH4A2Febteh';

    $conn = @new mysqli($host, $username, $password, $database, 3306);
    if ($conn->connect_error) {
        throw new Exception('No se pudo conectar a MySQL: ' . $conn->connect_error);
    }

    $conn->set_charset('utf8mb4');

    $bankName = trim($_POST['bankName'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $totalAssets = floatval($_POST['totalAssets'] ?? 0);
    $foundationYear = intval($_POST['foundationYear'] ?? 0);
    $interestRate = floatval($_POST['interestRate'] ?? 0);

    if (empty($bankName) || empty($country)) {
        throw new Exception('Nombre del banco y país son requeridos');
    }

    $sql = "INSERT INTO banks (bank_name, country, total_assets, fundation_year, interest_rate) VALUES (?, ?, ?, ?, ?)";
    $stmt = @$conn->prepare($sql);

    if (!$stmt) {
        $sql = "INSERT INTO banks (bank_name, country, total_assets, foundation_year, interest_rate) VALUES (?, ?, ?, ?, ?)";
        $stmt = @$conn->prepare($sql);
        if (!$stmt) {
            throw new Exception('Error en la base de datos: ' . $conn->error);
        }
    }

    $stmt->bind_param('ssdid', $bankName, $country, $totalAssets, $foundationYear, $interestRate);

    if (!$stmt->execute()) {
        throw new Exception('Error al insertar: ' . $stmt->error);
    }

    $insertId = $stmt->insert_id;
    $stmt->close();
    $conn->close();

    ob_end_clean();
    
    echo json_encode([
        'success' => true, 
        'message' => 'Banco insertado correctamente',
        'id' => $insertId
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    @ob_end_clean();
    
    echo json_encode([
        'success' => false, 
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

exit;
?>
