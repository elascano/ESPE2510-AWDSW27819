// Database configuration
const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

/**
 * Connects to MongoDB database
 * @returns {Promise<void>}
 */
const connectDatabase = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI);
    
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDatabase;
