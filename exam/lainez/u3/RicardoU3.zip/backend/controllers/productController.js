// Product Controller - Handles business logic for products
const Product = require('../models/Product');

/**
 * Get all products from database
 * @route GET /api/products
 */
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find({});
    
    res.status(200).json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching products from database',
      error: error.message
    });
  }
};

/**
 * Calculate total price of selected products
 * @route POST /api/calculate-total
 * @body {productIds: Array} - Array of 5 product IDs
 */
const calculateTotalPrice = async (req, res) => {
  try {
    const { productIds } = req.body;
    
    // Validate input
    if (!productIds || !Array.isArray(productIds)) {
      return res.status(400).json({
        success: false,
        message: 'Product IDs must be provided as an array'
      });
    }
    
    if (productIds.length !== 5) {
      return res.status(400).json({
        success: false,
        message: 'Exactly 5 products must be selected'
      });
    }
    
    // Fetch products from database
    const products = await Product.find({
      _id: { $in: productIds }
    });
    
    if (products.length !== 5) {
      return res.status(404).json({
        success: false,
        message: `Only ${products.length} products found. Please verify all product IDs exist.`
      });
    }
    
    // Calculate total with IVA using model method
    const calculation = Product.calculateTotal(products);
    
    res.status(200).json({
      success: true,
      subtotal: calculation.subtotal,
      iva: calculation.iva,
      ivaPercentage: 15,
      total: calculation.total,
      products: products.map(p => ({
        id: p._id,
        name: p.name,
        price: p.price,
        priceWithIva: parseFloat((p.price * 1.15).toFixed(2))
      }))
    });
  } catch (error) {
    console.error('Error calculating total:', error);
    res.status(500).json({
      success: false,
      message: 'Error calculating total price',
      error: error.message
    });
  }
};

module.exports = {
  getAllProducts,
  calculateTotalPrice
};
