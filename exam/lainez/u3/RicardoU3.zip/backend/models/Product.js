// Product Model - Defines the structure of products in the database
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative']
  },
  description: {
    type: String,
    trim: true
  }
}, {
  timestamps: true,
  collection: 'calculatePriceLainez'
});

/**
 * Calculates total price with IVA (15%) from an array of products
 * @param {Array} products - Array of product objects
 * @returns {Object} Object with subtotal, IVA, and total
 */
productSchema.statics.calculateTotal = function(products) {
  if (!Array.isArray(products) || products.length === 0) {
    return { subtotal: 0, iva: 0, total: 0 };
  }
  
  const IVA_RATE = 0.15; // 15%
  
  const subtotal = products.reduce((sum, product) => {
    return sum + (product.price || 0);
  }, 0);
  
  const iva = subtotal * IVA_RATE;
  const total = subtotal + iva;
  
  return {
    subtotal: parseFloat(subtotal.toFixed(2)),
    iva: parseFloat(iva.toFixed(2)),
    total: parseFloat(total.toFixed(2))
  };
};

const Product = mongoose.model('Product', productSchema);

module.exports = Product;
