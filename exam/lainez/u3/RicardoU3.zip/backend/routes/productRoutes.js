// Product Routes - Defines API endpoints
const express = require('express');
const router = express.Router();
const {
  getAllProducts,
  calculateTotalPrice
} = require('../controllers/productController');

// GET all products
router.get('/products', getAllProducts);

// POST calculate total price
router.post('/calculate-total', calculateTotalPrice);

module.exports = router;
