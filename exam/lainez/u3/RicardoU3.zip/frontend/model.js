// Frontend Model - Handles data and API communication
class ProductModel {
  constructor() {
    this.apiUrl = '/api';
    this.products = [];
    this.selectedProducts = [];
    this.maxSelection = 5;
  }

  /**
   * Fetches all products from the backend
   * @returns {Promise<Array>} Array of products
   */
  async fetchProducts() {
    try {
      const response = await fetch(`${this.apiUrl}/products`);
      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.message || 'Failed to fetch products');
      }
      
      this.products = data.data;
      return this.products;
    } catch (error) {
      console.error('Error fetching products:', error);
      throw error;
    }
  }

  /**
   * Toggles product selection
   * @param {String} productId - Product ID to toggle
   * @returns {Boolean} Success status
   */
  toggleProductSelection(productId) {
    const index = this.selectedProducts.indexOf(productId);
    
    if (index > -1) {
      // Product is already selected, remove it
      this.selectedProducts.splice(index, 1);
      return true;
    } else {
      // Check if we can add more products
      if (this.selectedProducts.length >= this.maxSelection) {
        return false;
      }
      // Add product to selection
      this.selectedProducts.push(productId);
      return true;
    }
  }

  /**
   * Checks if a product is selected
   * @param {String} productId - Product ID to check
   * @returns {Boolean}
   */
  isProductSelected(productId) {
    return this.selectedProducts.includes(productId);
  }

  /**
   * Gets the number of selected products
   * @returns {Number}
   */
  getSelectedCount() {
    return this.selectedProducts.length;
  }

  /**
   * Gets selected product objects
   * @returns {Array} Array of selected product objects
   */
  getSelectedProductsData() {
    return this.products.filter(p => this.selectedProducts.includes(p._id));
  }

  /**
   * Checks if exactly 5 products are selected
   * @returns {Boolean}
   */
  canCalculate() {
    return this.selectedProducts.length === this.maxSelection;
  }

  /**
   * Calculates total price by calling backend API
   * @returns {Promise<Object>} Result containing total and products
   */
  async calculateTotal() {
    try {
      if (!this.canCalculate()) {
        throw new Error(`Please select exactly ${this.maxSelection} products`);
      }

      const response = await fetch(`${this.apiUrl}/calculate-total`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          productIds: this.selectedProducts
        })
      });

      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.message || 'Failed to calculate total');
      }
      
      return data;
    } catch (error) {
      console.error('Error calculating total:', error);
      throw error;
    }
  }

  /**
   * Resets all selections
   */
  resetSelection() {
    this.selectedProducts = [];
  }
}

// Create global instance
const productModel = new ProductModel();
