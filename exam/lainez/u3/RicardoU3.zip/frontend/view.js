// Frontend View - Handles UI updates and user interactions
class ProductView {
  constructor() {
    this.products = document.getElementById('products');
    this.loading = document.getElementById('loading');
    this.error = document.getElementById('error');
    this.count = document.getElementById('count');
    this.calcBtn = document.getElementById('calc-btn');
    this.result = document.getElementById('result');
    this.subtotal = document.getElementById('subtotal');
    this.iva = document.getElementById('iva');
    this.total = document.getElementById('total');

    this.calcBtn.addEventListener('click', () => this.calculate());
    this.loadProducts();
  }

  async loadProducts() {
    try {
      this.loading.classList.remove('hidden');
      await productModel.fetchProducts();
      this.renderProducts();
      this.loading.classList.add('hidden');
    } catch (error) {
      this.loading.classList.add('hidden');
      this.error.textContent = 'Error: ' + error.message;
      this.error.classList.remove('hidden');
    }
  }

  renderProducts() {
    this.products.innerHTML = productModel.products.map(p => `
      <div class="product" data-id="${p._id}">
        <h3>${p.name}</h3>
        <div class="price">$${p.price.toFixed(2)}</div>
      </div>
    `).join('');

    document.querySelectorAll('.product').forEach(el => {
      el.addEventListener('click', () => this.toggle(el.dataset.id));
    });
  }

  toggle(id) {
    const success = productModel.toggleProductSelection(id);
    if (!success && !productModel.isProductSelected(id)) {
      alert('Maximum 5 products');
      return;
    }
    this.update();
  }

  update() {
    document.querySelectorAll('.product').forEach(el => {
      if (productModel.isProductSelected(el.dataset.id)) {
        el.classList.add('selected');
      } else {
        el.classList.remove('selected');
      }
    });

    const cnt = productModel.getSelectedCount();
    this.count.textContent = `Selected: ${cnt} / 5`;
    this.calcBtn.disabled = cnt !== 5;
    this.result.classList.add('hidden');
  }

  async calculate() {
    try {
      this.calcBtn.textContent = 'Calculating...';
      this.calcBtn.disabled = true;
      
      const res = await productModel.calculateTotal();
      
      this.subtotal.textContent = res.subtotal.toFixed(2);
      this.iva.textContent = res.iva.toFixed(2);
      this.total.textContent = res.total.toFixed(2);
      this.result.classList.remove('hidden');
      this.calcBtn.textContent = 'Calculate Total';
      this.calcBtn.disabled = false;
    } catch (error) {
      alert('Error: ' + error.message);
      this.calcBtn.textContent = 'Calculate Total';
      this.calcBtn.disabled = false;
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new ProductView();
});
