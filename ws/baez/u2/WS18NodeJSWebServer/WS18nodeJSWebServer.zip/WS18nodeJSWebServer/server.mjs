import express from "express";
const app = express();
const port = 3004;

app.get('/', (req, res) => {
    res.send('Welcome to Gabriel Báez Server!')
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});